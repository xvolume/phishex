<!DOCTYPE html>
<html  lang="en">
<head>
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<link rel="shortcut icon" href="/images/icons/favicons/fav_logo.ico?6" />

<link rel="apple-touch-icon" href="/images/icons/pwa/apple/default.png?8">

<meta http-equiv="content-type" content="text/html; charset=windows-1251" />
<meta name="description" content="VK is the largest European social network with more than 100 million active users. Our goal is to keep old friends, ex-classmates, neighbors and colleagues in touch." />


<title>Welcome&#33; | VK</title>

<noscript><meta http-equiv="refresh" content="0; URL=/badbrowser.php"></noscript>

<link rel="stylesheet" type="text/css" href="/css/al/common.css?66577870638" /><link rel="stylesheet" type="text/css" href="/css/al/base.css?1" /><link rel="stylesheet" type="text/css" href="/css/al/fonts_utf.css?1" /><link rel="stylesheet" type="text/css" href="/css/al/fonts_cnt.css?7802460376" />

<script type="text/javascript">
(function() {
var alertCont;
function trackOldBrowserEvent(event) {
  var xhr = new XMLHttpRequest();
  xhr.open('GET', '/badbrowser_stat.php?act=track&event=' + event);
  xhr.send();
}
function exposeGlobals() {
  window.hideOldBrowser = function() {
    alertCont.remove();
    var date = new Date();
    date.setTime(date.getTime() + (7 * 24 * 60 * 60 * 1000));
    var expiresDate = date.toGMTString();
    var domain = window.locDomain;
    document.cookie = 'remixoldbshown=1; expires=' + expiresDate + '; path=/' + (domain ? '; domain=.' + domain : '') + ';secure';
    trackOldBrowserEvent('hideAlert_atom');
  }
}
function checkOldBrowser() {
  if(!document.body) {
    setTimeout(checkOldBrowser, 100);
    return;
  }
  try {
    if (!('noModule' in HTMLScriptElement.prototype)) {
      exposeGlobals();
      var alert = '<div class="OldBrowser__container OldBrowser__container--atom" style="width:960px;">  Your browser is out of date For speed and stability when using VK, try <a href="https://vk.com/away.php?to=https%3A%2F%2F1l-go.mail.ru%2Fr%2Fadid%2F3010897_2013344%2Fpid%2F102819%2Fpof%2F1%2Ff%2F3%2F%3F_1larg_sub%3D505001%26utm_source%3Dvk%26rfr%3D505001&badbrowser=atom&badbrowser_meta=atom_with_player_badbrowser_alert&" target="_blank">Atom</a>. <a href="https://vk.com/away.php?to=https%3A%2F%2F1l-go.mail.ru%2Fr%2Fadid%2F3010897_2013344%2Fpid%2F102819%2Fpof%2F1%2Ff%2F3%2F%3F_1larg_sub%3D505001%26utm_source%3Dvk%26rfr%3D505001&badbrowser=atom&badbrowser_meta=atom_with_player_badbrowser_alert&" target="_blank">More</a>  <span class="OldBrowser__close" aria-label="Close" role="button" onclick="hideOldBrowser();"></span></div>';
      alertCont = document.createElement('div');
      alertCont.className = 'OldBrowser';
      alertCont.id = 'old_browser_wrap';
      alertCont.innerHTML = alert;
      document.body.appendChild(alertCont);
      trackOldBrowserEvent('showAlert_atom');
    }
  } catch(e) {}
}
checkOldBrowser();
})();
var vk = {
  ads_rotate_interval: 120000,
  al: parseInt('4') || 4,
  id: 0,
  intnat: '1' ? true : false,
  host: 'vk.com',
  loginDomain: 'https://login.vk.com/',
  lang: 3,
  statsMeta: {"platform":"web2","st":false,"time":1587391014,"hash":"7LPGCUb0JKmUT9uyZNPokqxeWj8p9rwF1VmkomNPuHD"},
  loaderNavSection: '',
  rtl: parseInt('') || 0,
  version: 1651521,
  stDomains: 0,
  stDomain: '',
  wsTransport: 'https://stats.vk-portal.net',
  stExcludedMasks: ["loader_nav","lang"],
  zero: false,
  contlen: 12578,
  loginscheme: 'https',
  ip_h: 'f3e524a9c338c1f2dd',
  navPrefix: '/',
  dt: parseInt('0') || 0,
  fs: parseInt('13') || 13,
  ts: 1587391014,
  tz: 10800,
  pd: 0,
  css_dir: '',
  vcost: 7,
  time: [2020, 4, 20, 16, 56, 54],
  sampleUser: -1, spentLastSendTS: new Date().getTime(),
  a11y: 0,
  statusExportHash: '',
  audioAdsConfig: {"_":"_"},
  longViewTestGroup: "every_view",
  cma: 1,
  lpConfig: {
    enabled: 0,
    key: '',
    ts: 0,
    url: '',
    lpstat: 0
  },

  pr_tpl: "<div class=\"pr %cls%\" id=\"%id%\"><div class=\"pr_bt\"><\/div><div class=\"pr_bt\"><\/div><div class=\"pr_bt\"><\/div><\/div>",
  push_hash: '773350a7cb558daad3',

  audioInlinePlayerTpl: "<div class=\"audio_inline_player _audio_inline_player no_select\">\n  <div class=\"audio_inline_player_right\">\n    <div class=\"audio_inline_player_volume\"><\/div>\n  <\/div>\n  <div class=\"audio_inline_player_left\">\n    <div class=\"audio_inline_player_progress\"><\/div>\n  <\/div>\n<\/div>",

  tnsPixelType: 'unauth',
  tnsPixelSocdem: '13',

  pe: {"article_poll":1,"vk_apps_svg_qr":1,"upload.send_upload_stat":1,"push_notifier":1,"audio_search_new_catalog":1,"story_reactions_web":1,"notify_new_events_box":1,"web_ajax_json_object":1,"mini_apps_web_add_to_favorites":1,"cookie_secure_default_true":1,"mvk_new_info_snackbar":1,"market_with_products_of_groups":1,"apps_promo_share_story":1,"widgets_xdm_same_origin":1,"stickers_money_transfer_suggestions":1,"web2_story_box_enabled":1,"gifts_stickers_preview_tooltips":1,"performance_box_opening":1,"easy_market_promote_new_payment":1,"navigation_timespent":1,"mvk_mediascope_counter":1,"market_item_recommendations_view_log":1,"market_item_others_view_log":1,"web_stats_transport_story_view":1},
  countryISO: 'CA',
};;vk.rv="101752";;if (!window.constants) { window.constants = {Groups: {
  GROUPS_ADMIN_LEVEL_USER: 0,
  GROUPS_ADMIN_LEVEL_MODERATOR: 1,
  GROUPS_ADMIN_LEVEL_EDITOR: 2,
  GROUPS_ADMIN_LEVEL_ADMINISTRATOR: 3,
  GROUPS_ADMIN_LEVEL_HOST: 4,
  GROUPS_ADMIN_LEVEL_EVENT_CREATOR: 5,
  GROUPS_ADMIN_LEVEL_CREATOR: 6,
  GROUPS_ADMIN_PSEUDO_LEVEL_ADVERTISER: 100
}}; };

window.locDomain = vk.host.match(/[a-zA-Z]+\.[a-zA-Z]+\.?$/)[0];
var _ua = navigator.userAgent.toLowerCase();
if (/opera/i.test(_ua) || !/msie 6/i.test(_ua) || document.domain != locDomain) document.domain = locDomain;
var ___htest = (location.toString().match(/#(.*)/) || {})[1] || '', ___to;
___htest = ___htest.split('#').pop();
if (vk.al != 1 && ___htest.length && ___htest.substr(0, 1) == vk.navPrefix) {
  if (vk.al != 3 || vk.navPrefix != '!') {
    ___to = ___htest.replace(/^(\/|!)/, '');
    if (___to.match(/^([^\?]*\.php|login|mobile|away)([^a-z0-9\.]|$)/)) ___to = '';
    location.replace(location.protocol + '//' + location.host + '/' + ___to);
  }
}

var StaticFiles = {
  'cmodules/web/common_web.js' : {v: '167'},
  'common.css':{v:66577870638},'base.css':{v:1},'fonts_utf.css':{v:1},'fonts_cnt.css':{v:7802460376}
  ,'cmodules/bundles/audioplayer.2f2a9e9e1033b710cdfc.js':{v:'cd5c9af25207f6870c7c'},'cmodules/bundles/common.b4f0b5149370f45d6bc4.js':{v:'1745f27d4d863d4d7c4d'},'cmodules/web/common_web.6969ffacf4e3402bf177.js':{v:'41a81fd0a05f119e81520d2b7e16becb'},'lang3_0.js': {v: 26456516},'login.css':{v:29063788890},'index.css':{v:23578188627},'cmodules/web/index.ef9f5939783fefea966e.js':{v:'70a98120b1df1f3d5db48e5ffef04927'},'cmodules/web/index.js':{v:34},'ui_controls.css':{v:19196595404},'ui_controls.js':{v:3874811298},'cmodules/web/jobs_devtools_notification.4df10ae32f805993d431.js':{v:'d49c6c2f1edadd7f58fc443a53597c6a'},'cmodules/web/jobs_devtools_notification.js':{v:1},'cmodules/web/page_layout.74b6a1e8a066891ffa6a.js':{v:'a79fa6f5402f462d974f'},'cmodules/web/page_layout.js':{v:1},'cmodules/bundles/40078178da81a2a294c33d2feddcc76c.bc8473a712e22f821a5d.js':{v:'93299476685236438c18'},'cmodules/bundles/2bddcf8eba73bbb0902e1b2f9d33962b.398943f516a729749eb0.js':{v:'a346646ed8db83f74021'},'cmodules/web/ui_common.c651bb427c7f566d4b04.js':{v:'7d8603dda26eb5b7b3d6f0302b83c540'},'ui_common.js':{v:6},'ui_common.css':{v:18981215481},'cmodules/bundles/f8a3b0b69a90b5305d627c89f0bd674e.0ddcf139530f9eca6bfb.js':{v:'55d06b92f78d1803b139'},'cmodules/web/likes.e06fa24ccc77d308d77a.js':{v:'6c7adaa3514b1e8e2d88b756ef0dd6a2'},'cmodules/web/likes.js':{v:1},'cmodules/web/grip.4e3739b310753afb9593.js':{v:'77cc88636dab4d4ab43fe764d6c1db18'},'cmodules/web/grip.js':{v:1}
}
var abp;
</script>

<link type="text/css" rel="stylesheet" href="/css/al/login.css?29063788890" /><link type="text/css" rel="stylesheet" href="/css/al/index.css?23578188627" /><link type="text/css" rel="stylesheet" href="/css/ui_controls.css?19196595404" /><link type="text/css" rel="stylesheet" href="/css/al/ui_common.css?18981215481" /><script type="text/javascript" src="/js/loader_nav1651521_3.js"></script><script type="text/javascript" src="/js/cmodules/bundles/audioplayer.2f2a9e9e1033b710cdfc.js?cd5c9af25207f6870c7c"></script><script type="text/javascript" src="/js/cmodules/bundles/common.b4f0b5149370f45d6bc4.js?1745f27d4d863d4d7c4d"></script><script type="text/javascript" src="/js/cmodules/web/common_web.6969ffacf4e3402bf177.js?41a81fd0a05f119e81520d2b7e16becb"></script><script type="text/javascript" src="/js/lang3_0.js?26456516"></script><script type="text/javascript" src="/js/lib/px.js?ch=1"></script><script type="text/javascript" src="/js/lib/px.js?ch=2"></script><link rel="alternate" media="only screen and (max-width: 640px)" href="https://m.vk.com/join" /><link rel="alternate" href="android-app://com.vkontakte.android/vkontakte/m.vk.com/join" /><meta name="msApplication-ID" content="C6965DD5.VK" /><meta name="msApplication-PackageFamilyName" content="C6965DD5.VK_v422avzh127ra" /><meta name="google-site-verification" content="CNjLCRpSR2sryzCC4NQKKCL5WnvmBTaag2J_UlTyYeQ" /><meta name="yandex-verification" content="798f8402854bea07" /><script type="text/javascript" src="/js/cmodules/web/index.ef9f5939783fefea966e.js?70a98120b1df1f3d5db48e5ffef04927"></script><script type="text/javascript" src="/js/lib/ui_controls.js?3874811298"></script><script type="text/javascript" src="/js/cmodules/web/jobs_devtools_notification.4df10ae32f805993d431.js?d49c6c2f1edadd7f58fc443a53597c6a"></script><script type="text/javascript" src="/js/cmodules/web/page_layout.74b6a1e8a066891ffa6a.js?a79fa6f5402f462d974f"></script><script type="text/javascript" src="/js/cmodules/bundles/40078178da81a2a294c33d2feddcc76c.bc8473a712e22f821a5d.js?93299476685236438c18"></script><script type="text/javascript" src="/js/cmodules/bundles/2bddcf8eba73bbb0902e1b2f9d33962b.398943f516a729749eb0.js?a346646ed8db83f74021"></script><script type="text/javascript" src="/js/cmodules/web/ui_common.c651bb427c7f566d4b04.js?7d8603dda26eb5b7b3d6f0302b83c540"></script><script type="text/javascript" src="/js/cmodules/bundles/f8a3b0b69a90b5305d627c89f0bd674e.0ddcf139530f9eca6bfb.js?55d06b92f78d1803b139"></script><script type="text/javascript" src="/js/cmodules/web/likes.e06fa24ccc77d308d77a.js?6c7adaa3514b1e8e2d88b756ef0dd6a2"></script><script type="text/javascript" src="/js/cmodules/web/grip.4e3739b310753afb9593.js?77cc88636dab4d4ab43fe764d6c1db18"></script>

</head>

<body onresize="onBodyResize()" class="index_page">
  <div id="system_msg" class="fixed"></div>
  <div id="utils"></div>

  <div id="layer_bg" class="fixed"></div><div id="layer_wrap" class="scroll_fix_wrap fixed layer_wrap"><div id="layer"></div></div>
  <div id="box_layer_bg" class="fixed"></div><div id="box_layer_wrap" class="scroll_fix_wrap fixed"><div id="box_layer"><div id="box_loader"><div class="pr pr_baw pr_medium" id="box_loader_pr"><div class="pr_bt"></div><div class="pr_bt"></div><div class="pr_bt"></div></div><div class="back"></div></div></div></div>

  <div id="stl_left"></div><div id="stl_side"></div>

  <script type="text/javascript">window.domStarted && domStarted();</script>

  <div class="scroll_fix_wrap _page_wrap" id="page_wrap"><div><div class="scroll_fix">
  

  <div id="page_header_cont" class="page_header_cont">
    <div class="back"></div>
    <div id="page_header_wrap" class="page_header_wrap">
      <a class="top_back_link" href="" id="top_back_link" onclick="if (nav.go(this, event, {back: true}) === false) { showBackLink(); return false; }"></a>
      <div id="page_header" class="p_head1 p_head_l3" style="width: 960px">
        <div class="content">
          <div id="top_nav" class="head_nav">
  <div class="head_nav_item fl_l"><a class="top_home_link fl_l CovidLogo" href="/" aria-label="Home" accesskey="1"  onmouseover="this.className.indexOf(&#39;bugtracker_logo&#39;) === -1 &amp;&amp; bodyNode.className.indexOf(&#39;WideScreenAppPage&#39;) === -1 &amp;&amp; showTooltip(this,
{
  text: &quot;&lt;div class=\&quot;CovidTooltip__logo\&quot;&gt;&lt;\/div&gt;&lt;div class=\&quot;CovidTooltip__title\&quot;&gt;Stay home&lt;\/div&gt;&lt;div class=\&quot;CovidTooltip__text\&quot;&gt;Wash your hands, maintain social distancing, stay�at�home if you can, and�&lt;a href=\&quot;\/feed?section=stayhome\&quot; onclick=\&quot;return typeof window.statlogsValueEvent !== &amp;#39;undefined&amp;#39; &amp;amp;&amp;amp; window.statlogsValueEvent(&amp;#39;coronavirus_tooltip_click&amp;#39;, 1) || nav.go(this, event)\&quot;&gt;keep�busy&lt;\/a&gt;.&lt;\/div&gt;&quot;,
  className: &#39;CovidTooltip&#39;,
  width: 356,
  dir: &#39;top&#39;,
  shift: [0, 0, 6],
  hidedt: 60, showdt: 600,
  hasover: true,
  onShowStart: function() {window.statlogsValueEvent !== &#39;undefined&#39; &amp;&amp; window.statlogsValueEvent(&#39;coronavirus_tooltip_show&#39;, 1)}
})"><div class="top_home_logo"></div><div class="CovidLogo__hashtag ">#stayhome</div></a></div>
  <div class="head_nav_item fl_l"><div id="ts_wrap" class="ts_wrap" onmouseover="TopSearch.initFriendsList();">
  <input name="disable-autofill" style="display: none;" />
  <input type="text" onmousedown="event.cancelBubble = true;" ontouchstart="event.cancelBubble = true;" class="text ts_input" id="ts_input" autocomplete="off" name="disable-autofill" placeholder="Search" aria-label="Search" />
</div></div>
  <div class="head_nav_item fl_l head_nav_btns"><div id="top_audio_layer_place" class="top_audio_layer_place"></div></div>
  <div class="head_nav_item fl_r"><a class="top_nav_link" href="" id="top_switch_lang" style="display: none;" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 3, hash: '' }); return false;">
  Switch to English
</a><a class="top_nav_link" href="/join" id="top_reg_link" style="display: none" onclick="return !showBox('join.php', {act: 'box', from: nav.strLoc}, {}, event)">
  sign up
</a></div>
  <div class="head_nav_item_player"></div>
</div>
<div id="ts_cont_wrap" class="ts_cont_wrap" ontouchstart="event.cancelBubble = true;" onmousedown="event.cancelBubble = true;"></div>
        </div>
      </div>
    </div>
  </div>

  <div id="page_layout" style="width: 960px;">
    <div id="side_bar" class="side_bar fl_l  sticky_top_force" style="display: none">
      <div id="side_bar_inner" class="side_bar_inner">
        <div id="quick_login" class="quick_login">
  <form method="POST" name="login" id="quick_login_form" action="https://login.vk.com/?act=login">
    <input type="hidden" name="act" value="login" />
    <input type="hidden" name="role" value="al_frame" />
    <input type="hidden" name="expire" id="quick_expire_input" value="" />
    <input type="hidden" name="recaptcha" id="quick_recaptcha" value="" />
    <input type="hidden" name="captcha_sid" id="quick_captcha_sid" value="" />
    <input type="hidden" name="captcha_key" id="quick_captcha_key" value="" />
    <input type="hidden" name="_origin" value="https://vk.com" />
    <input type="hidden" name="ip_h" value="f3e524a9c338c1f2dd" />
    <input type="hidden" name="lg_h" value="34bc118bdee53cf444" />
    <input type="hidden" name="ul" id="quick_login_ul" value="" />
    <div class="label">Phone or email</div>
    <div class="labeled"><input type="text" name="email" class="dark" id="quick_email" /></div>
    <div class="label">Password</div>
    <div class="labeled"><input type="password" name="pass" class="dark" id="quick_pass" onkeyup="toggle('quick_expire', !!this.value);toggle('quick_forgot', !this.value)" /></div>
    <input type="submit" class="submit" />
  </form>
  <button class="quick_login_button flat_button button_wide" id="quick_login_button">Log in</button>
  <button class="quick_reg_button flat_button button_wide" id="quick_reg_button" style="display: none" onclick="top.showBox('join.php', {act: 'box', from: nav.strLoc})">Sign up</button>
  <div class="clear forgot"><div class="checkbox" id="quick_expire" onclick="checkbox(this);ge('quick_expire_input').value=isChecked(this)?1:'';">Don&#39;t remember me</div><a id="quick_forgot" class="quick_forgot" href="/restore" target="_top">Forgot your password?</a></div>
</div>
      </div>
    </div>

    <div id="page_body" class="fl_r " style="width: 960px;">
      
      <div id="wrap_between"></div>
      <div id="wrap3"><div id="wrap2">
  <div id="wrap1">
    <div id="content"><div id="index_rcolumn" class="index_rcolumn">
  <div id="index_login" class="page_block index_login">
    <form method="post" name="login" id="index_login_form" action="https://login.vk.com/?act=login">
      <input type="hidden" name="act" id="act" value="login">
      <input type="hidden" name="role" value="al_frame" />
      <input type="hidden" name="expire" id="index_expire_input" value="" />
      <input type="hidden" name="_origin" value="https://vk.com" />
      <input type="hidden" name="ip_h" value="f3e524a9c338c1f2dd" />
      <input type="hidden" name="lg_h" value="d81d2f517c6b6799f6" />
      <input type="text" class="big_text" name="email" id="index_email" value="" placeholder="Phone or email" />
      <input type="password" class="big_text" name="pass" id="index_pass" value="" placeholder="Password" onkeyup="toggle('index_expire', !!this.value);toggle('index_forgot', !this.value)" />
      <button id="index_login_button" class="index_login_button flat_button button_big_text">Log in</button>
      <div class="forgot">
        <div class="checkbox" id="index_expire" onclick="checkbox(this);ge('index_expire_input').value=isChecked(this)?1:'';">Don&#39;t remember me</div>
        <a id="index_forgot" class="index_forgot" href="/restore" target="_top">Forgot your password?</a>
      </div>
    </form>
  </div>
  <div id="ij_form" class="page_block ij_form">
    <h2 class="ij_header">First time on VK?</h2>
    <div class="ij_subheader">Sign up for VK</div>
    <div id="ij_msg"></div>
    <input type="text" class="big_text" id="ij_first_name" value="" placeholder="Your first name" />
    <input type="text" class="big_text" id="ij_last_name" value="" placeholder="Your last name" />
    <div class="ij_label">Birthday<span class="hint_icon" data-title="&lt;b&gt;By providing your birthday&lt;/b&gt;, your friends will be able to find you more easily and help us select interesting content to recommend to you.&lt;br&gt;You can edit your profile to manage who can view your birthday." onmouseover="showHint(this);"></span></div>
    <div id="ij_birthdate_row" class="ij_birthdate_row clear_fix">
      <div class="ij_bday"><input type="text" class="big_text" id="ij_bday" /></div>
      <div class="ij_bmonth"><input type="text" class="big_text" id="ij_bmonth" /></div>
      <div class="ij_byear"><input type="text" class="big_text" id="ij_byear" /></div>
    </div>
    <div id="ij_sex_row" class="clear_fix">
      <div class="ij_label">Your gender</div>
      <div class="radiobtn" onclick="radiobtn(this, 1, 'ij_sex');">Female</div>
      <div class="radiobtn" onclick="radiobtn(this, 2, 'ij_sex');">Male</div>
    </div>
    <button class="flat_button button_wide button_big_text ij_button" id="ij_submit" onclick="Index.submitJoinStart()">Continue registration</button>
    <div id="index_fbcontinuewithsign" class="FacebookLogin FacebookLogin--index FacebookLogin--noNative">
      <div class="FacebookLogin__button fb-login-button"
        onclick="return Index.fbJoin();"
        data-use-continue-as="true"
        data-width="264"
        data-max-rows="1"
        data-size="medium"
        data-button-type="continue_with"
        data-placeholder="Log in with Facebook"
      ></div>
    </div>
  </div>
</div>
<div class="LoginMobilePromo clear_fix">
  <div class="login_mobile_apps">
    <div class="login_mobile_header">VK for mobile devices</div>
    <div class="login_mobile_info">Install our official mobile app and stay in touch with your friends anytime and anywhere.</div>
    

    <div class="LoginMobilePromo__devices">
      <a class="LoginMobilePromoDevice LoginMobilePromoDevice--android LoginMobilePromoDevice--en" target="_blank" href="https://play.google.com/store/apps/details?id=com.vkontakte.android">
        <span class="LoginMobilePromoDevice__button flat_button secondary button_light">VK for Android</span>
      </a>
      <a class="LoginMobilePromoDevice LoginMobilePromoDevice--ios LoginMobilePromoDevice--en" target="_blank" href="https://itunes.apple.com/app/id564177498">
        <span class="LoginMobilePromoDevice__button flat_button secondary button_light">VK for iPhone</span>
      </a>
    </div>

    <a href="/products" class="login_all_products_button">All products</a>
  </div>
  <a onclick="curBox().hide()" id="login_mobile_close" class="login_mobile_close"></a>

  <div class="login_about_mobile">
    Use this short address to access the mobile version of VK.com from your phone: <a target="_blank" href="https://m.vk.com">m.vk.com</a>
  </div>
</div>
<div id="index_footer_wrap" class="footer_wrap index_footer_wrap">
  <div class="footer_nav" id="bottom_nav">
  <div class="footer_copy"><a href="/about">VK</a> &copy; 2006�2020</div>
  <div class="footer_links">
    <a class="bnav_a" href="/about">About VK</a>
    <a class="bnav_a" href="/support?act=home" style="display: none;">Help</a>
    <a class="bnav_a" href="/terms">Terms</a>
    <a class="bnav_a" href="/ads" style="display: none;">Ads</a>
    
    <a class="bnav_a" href="/dev">Developers</a>
    <a class="bnav_a" href="/jobs" style="display: none;">Jobs</a>
  </div>
  <div class="footer_lang"><a class="footer_lang_link" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 3, hash: '425e1ee3248f21fd97'})">English</a><a class="footer_lang_link" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 0, hash: '425e1ee3248f21fd97'})">�������</a><a class="footer_lang_link" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 1, hash: '425e1ee3248f21fd97'})">���������</a><a class="footer_lang_link" onclick="if (vk.al) { showBox('lang.php', {act: 'lang_dialog', all: 1}, {params: {dark: true, bodyStyle: 'padding: 0px'}, noreload: true}); } else { changeLang(1); } return false;">all languages �</a></div>
</div>

<div class="footer_bench clear">
  
</div>
</div></div>
  </div>
</div></div>
    </div>

    <div id="footer_wrap" class="footer_wrap fl_r" style="width: 960px;"><div class="footer_nav" id="bottom_nav">
  <div class="footer_copy"><a href="/about">VK</a> &copy; 2006�2020</div>
  <div class="footer_links">
    <a class="bnav_a" href="/about">About VK</a>
    <a class="bnav_a" href="/support?act=home" style="display: none;">Help</a>
    <a class="bnav_a" href="/terms">Terms</a>
    <a class="bnav_a" href="/ads" style="display: none;">Ads</a>
    
    <a class="bnav_a" href="/dev">Developers</a>
    <a class="bnav_a" href="/jobs" style="display: none;">Jobs</a>
  </div>
  <div class="footer_lang"><a class="footer_lang_link" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 3, hash: '425e1ee3248f21fd97'})">English</a><a class="footer_lang_link" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 0, hash: '425e1ee3248f21fd97'})">�������</a><a class="footer_lang_link" onclick="ajax.post('al_index.php', {act: 'change_lang', lang_id: 1, hash: '425e1ee3248f21fd97'})">���������</a><a class="footer_lang_link" onclick="if (vk.al) { showBox('lang.php', {act: 'lang_dialog', all: 1}, {params: {dark: true, bodyStyle: 'padding: 0px'}, noreload: true}); } else { changeLang(1); } return false;">all languages �</a></div>
</div>

<div class="footer_bench clear">
  
</div></div>

    <div class="clear"></div>
  </div>
</div></div><noscript><div style="position:absolute;left:-10000px;">
<img src="//top-fwz1.mail.ru/counter?id=2579437;js=na" style="border:0;" height="1" width="1" />
</div></noscript></div>
  <div class="progress" id="global_prg"></div>

  <script type="text/javascript">
    if (parent && parent != window && (browser.msie || browser.opera || browser.mozilla || browser.chrome || browser.safari || browser.iphone)) {
      document.getElementsByTagName('body')[0].innerHTML = '';
    } else {
      window.domReady && domReady();
      updateMoney(0);
initPageLayoutUI();
if (browser.iphone || browser.ipad || browser.ipod) {
  setStyle(bodyNode, {webkitTextSizeAdjust: 'none'});
}var qf = ge('quick_login_form'), ql = ge('quick_login'), qe = ge('quick_email'), qp = ge('quick_pass');
var qlb = ge('quick_login_button'), prgBtn = qlb;

var qinit = function() {
  setTimeout(function() {
    ql.insertBefore(ce('div', {innerHTML: '<iframe class="upload_frame" id="quick_login_frame" name="quick_login_frame"></iframe>'}), qf);
    qf.target = 'quick_login_frame';
    qe.onclick = loginByCredential;
    qp.onclick = loginByCredential;
  }, 1);
}

if (window.top && window.top != window) {
  window.onload = qinit;
} else {
  setTimeout(qinit, 0);
}

qf.onsubmit = function() {
  if (!ge('quick_login_frame')) return false;
  if (!val('quick_login_ul') && !trim(qe.value)) {
    notaBene(qe);
    return false;
  } else if (!trim(qp.value)) {
    notaBene(qp);
    return false;
  }
  lockButton(window.__qfBtn = prgBtn);
  prgBtn = qlb;
  clearTimeout(__qlTimer);
  __qlTimer = setTimeout(loginSubmitError, 30000);
  domFC(domPS(qf)).onload = function() {
    clearTimeout(__qlTimer);
    __qlTimer = setTimeout(loginSubmitError, 2500);
  }
  return true;
}

window.loginSubmitError = function() {
  showFastBox('Warning', 'Unable to complete encrypted authorization. This can happen if your date and time settings are not configured correctly on your system. Please check your date &amp; time settings and restart the browser.');
}
window.focusLoginInput = function() {
  scrollToTop(0);
  notaBene('quick_email');
}
window.changeQuickRegButton = function(noShow) {
  if (noShow) {
    hide('top_reg_link', 'quick_reg_button');
  } else {
    show('top_reg_link', 'quick_reg_button');
  }
  toggle('top_switch_lang', noShow && window.langConfig && window.langConfig.id != 3);
}
window.submitQuickLoginForm = function(email, pass, opts) {
  setQuickLoginData(email, pass, opts);
  if (opts && opts.prg) prgBtn = opts.prg;
  if (qf.onsubmit()) qf.submit();
}
window.setQuickLoginData = function(email, pass, opts) {
  if (email !== undefined) ge('quick_email').value = email;
  if (pass !== undefined) ge('quick_pass').value = pass;
  var params = opts && opts.params || {};
  each (params, function(i, v) {
    var el = ge('quick_' + i) || ge('quick_login_' + i);;
    if (el) {
      val(el, params[i]);
    } else {
      qf.appendChild(ce('input', {type: 'hidden', name: i, id: 'quick_login_' + i, value: v}));
    }
  });
}
window.loginByCredential = function() {
  if (!browserFeatures.cmaEnabled || !window.submitQuickLoginForm || window._loginByCredOffered) return false;

  _loginByCredOffered = true;
  navigator.credentials.get({
    password: true,
    mediation: 'required'
  }).then(function(cred) {
    if (cred) {
      submitQuickLoginForm(cred.id, cred.password);
      return true;
    } else {
      return false;
    }
  });
}

if (qlb) {
  qlb.onclick = function() { if (qf.onsubmit()) qf.submit(); };
}

if (browser.opera_mobile) show('quick_expire');

if (1) {
  hide('support_link_td', 'top_support_link');
}
var ts_input = ge('ts_input');
if (ts_input) {
  placeholderSetup(ts_input, {back: false, reload: true, phColor: '#8fadc8'});
}
TopSearch.init();;window.shortCurrency && shortCurrency();
window.handlePageParams && handlePageParams({"id":0,"loc":null,"noleftmenu":1,"wrap_page":1,"width":960,"width_dec":0,"width_dec_footer":0,"top_home_link_class":"top_home_link fl_l CovidLogo","body_class":"index_page","counters":"","pvbig":0,"pvdark":1});addEvent(document, 'click', onDocumentClick);
addLangKeys({"global_apps":"Apps","global_friends":"Friends","global_communities":"Communities","head_search_results":"Search results","global_chats":"Chats","global_show_all_results":"Show all results","global_news_search_results":"Search results by news","global_emoji_cat_recent":"Frequently Used","global_emoji_cat_1":"Faces","global_emoji_cat_2":"Animals &amp; Nature","global_emoji_cat_3":"Hands &amp; People","global_emoji_cat_4":"Food &amp; Drink","global_emoji_cat_5":"Activity","global_emoji_cat_6":"Travel &amp; Transport","global_emoji_cat_7":"Objects","global_emoji_cat_8":"Symbols","global_emoji_cat_9":"Flags","stories_archive_privacy_info":"Only you can see your archived stories","stories_remove_warning":"Are you sure you want to delete this story?<br>This cannot be undone.","stories_narrative_remove_warning":"Are you sure you want to delete this narrative?<br>This cannot be undone.","stories_remove_confirm":"Delete","stories_answer_placeholder":"Your message�","stories_answer_sent":"Message sent","stories_blacklist_title":"Hidden from Stories","stories_settings":"Settings","stories_add_blacklist_title":"Hide from stories","stories_add_blacklist_message":"This user&#39;s stories won&#39;t appear in your feed, but you&#39;ll stay friends.","stories_add_blacklist_button":"Hide from stories","stories_add_blacklist_message_group":"This community&#39;s stories won&#39;t appear in your feed, but you&#39;ll still be a follower.","stories_remove_from_blacklist_button":"Show in stories","stories_error_cant_load":"Unable to load the story.","stories_try_again":"Try again","stories_error_expired":"&#8203;&#8203;The story could have been viewed<br>within 24 hours after being created","stories_error_deleted":"Story deleted","stories_error_private":"Story hidden by author","stories_error_one_time_seen":"This story is no longer available","stories_mask_tooltip":"Try this mask","stories_mask_sent":"Mask sent to phone","stories_followed":"Started following&#33;","stories_unfollowed":"You&#39;ve unfollowed","stories_is_ad":"Advertisment","stories_private_story":"Private<br>story","stories_expired_story":"Story<br>expired","stories_deleted_story":"Story<br>deleted","stories_bad_browser":"Stories are not supported by your browser","stories_delete_all_replies_confirm":"Are you sure you want to delete all of {name}&#39;s replies from last 24 hours?<br>This cannot be undone.","stories_hide_reply_button":"Hide reply","stories_reply_hidden":"Story reply hidden.","stories_restore":"Restore","stories_hide_reply_continue":"Return to replies","stories_hide_all_replies":["","Hide all of his replies from the last 24 hours","Hide all of her replies from the last 24 hours"],"stories_reply_add_to_blacklist":"Block","stories_hide_reply_warning":"Are you sure you want to hide this reply?<br>This cannot be undone.","stories_replies_more_button":["","Show %s more commenter","Show %s more commenters"],"stories_all_replies_hidden":"All replies hidden","stories_ban_confirm":"Are you sure you want to block {name}?<br>This cannot be undone.","stories_banned":"The user has been blocked","stories_share":"Share","stories_like":"Like","stories_follow":"Follow","stories_unfollow":"Unfollow","stories_report":"Report","stories_report_sent":"Report sent","stories_narrative_show":"View narrative","stories_narrative_bookmark_added":"Narrative added to {link}Bookmarks{\/link}","stories_narrative_bookmark_deleted":"Narrative removed from Bookmarks","stories_narrative_edit_button":"Edit narrative","stories_narrative_add_bookmark_button":"Add to Bookmarks","stories_narrative_remove_bookmark_button":"Remove from Bookmarks","stories_show_hashtag_link":"Search hashtag","stories_go_to_place":"Go to place","stories_go_to_group":"Open community","stories_go_to_profile":"Open profile","stories_go_to_post":"Go to post","stories_go_to_story":"Open story","stories_share_question":"Give feedback","stories_live_ended_title":"Thanks for watching&#33;","stories_live_ended_desc_club":"{name} finished <br>the live stream.","stories_live_ended_desc_user":["","{name} finished the live stream.","{name} finished the live stream."],"stories_live_ended_open_club":"Open community","stories_live_ended_open_user":"Open profile","stories_live_ended_watch_next":"Watch next","stories_live_N_watching":["","%s watching now","%s watching now"],"stories_live_chat_msg_too_long":"Message too long","stories_questions_title":"Feedback","stories_question_reply":"Respond","stories_question_reply_error":"Unfortunately, your message cannot be sent due to this user&#39;s privacy settings.","stories_question_reply_send":"Send","stories_question_reply_placeholder":"Write a message...","stories_question_delete":"Delete feedback","stories_question_author_ban":"Block","stories_question_author_unban":"Unblock author","stories_question_author_blocked":"Author blocked","stories_question_author_unblocked":"Author unblocked","stories_question_author_report":"Report","stories_question_report_title":"Report feedback","stories_question_report_send":"Send","stories_question_more":"More options","stories_question_sent":"You gave feedback to {name}","stories_question_reply_box_title":"Message to {name}","stories_question_ask_placeholder":"Enter your feedback...","stories_question_ask_box_title":"Feedback on {name}&#39;s story","stories_question_report_reason":"Select a reason","stories_question_forbidden":"You can&#39;t give feedback","stories_audio_add":"Add to my music","stories_audio_added":"Track added","stories_audio_delete":"Delete track","stories_audio_deleted":"Track deleted","stories_audio_next_audio":"Play next","stories_reactions_title":"Quick reactions","stories_reactions_tooltip_feature":"Now you can quickly react to the story","stories_go_to_market_item":"More info","stories_market_access_error_title":"Error","stories_market_access_error_text":"Product unavailable","stories_groups_feed_block":"Communities","stories_settings_box_tab_all":"All","stories_settings_box_tab_separately":"Shown separately","stories_settings_box_tab_grouped":"Grouped","stories_settings_box_search_placeholder":"Search communities","stories_settings_box_put_back":"Show last","stories_groups_grid_title":"Community stories","stories_go_to_app":"Go to mini app","stories_groups_grid_text":"This is where you can find stories from communities that you&#39;re following","stories_groups_tooltip":"Mark stories that you want to see in your stories feed","stories_settings_saved":"Settings saved","stories_question_select_public":"Publicly","stories_question_select_author_only":"Author only","stories_question_select_anonymous":"Anonymously","stories_question_about_user_tooltip":"<b>Public<\/b><br>{name} will be able to add your name when sharing your feedback.<br><br><b>Name visible to author<\/b><br>{name} will see your name but won&#39;t be able to add it when sharing your feedback.<br><br><b>Anonymous<\/b><br>{name} won&#39;t see your name and won&#39;t be able to add it when sharing your feedback.","stories_question_about_group_tooltip":"<b>Public<\/b><br>Community managers will be able to add your name when sharing your feedback.<br><b>Name visible to author<\/b><br>Community managers will see your name but won&#39;t be able to add it when sharing your feedback.<br><b>Anonymous<\/b><br>Community managers won&#39;t see your name and won&#39;t be able to add it when sharing your feedback.","stories_question_about_user_tooltip_without_anon":"<b>Public<\/b><br>{name} will be able to add your name when sharing your feedback.<br><br><b>Name visible to author<\/b><br>{name} will see your name but won&#39;t be able to add it when sharing your feedback.","stories_question_about_group_tooltip_without_anon":"<b>Public<\/b><br>Community managers will be able to add your name when sharing your feedback.<br><br><b>Name visible to author<\/b><br>Community managers will see your name but won&#39;t be able to add it when sharing your feedback."}, true);
addLangKeys({"index_to_main":"Home","index_choose_sex":"Select gender","index_sel_bday":"Day","box_close":"Close","captcha_cancel":"Cancel","captcha_enter_code":"Enter the code from the picture","captcha_send":"Send","global_back":"Back","global_box_title_back":"Back","global_captcha_input_here":"Enter code","global_close":"Close","global_date":["","{day} {month} {year}","yesterday","today","tomorrow"],"global_error":"Error","global_hours_ago":["","%s hour ago","%s hours ago"],"global_just_now":"just now","global_mins_ago":["","%s minute ago","%s minutes ago"],"global_recaptcha_title":"Confirm action","global_short_date":["","{month} {day}","yesterday","today","tomorrow"],"global_short_date_time":["","{day} {month} at {hour}:{minute} {am_pm}","yesterday at {hour}:{minute} {am_pm}","today at {hour}:{minute} {am_pm}","tomorrow at {hour}:{minute} {am_pm}"],"global_short_date_time_l":["","{day} {month} at {hour}:{minute} {am_pm}","yesterday at {hour}:{minute} {am_pm}","today at {hour}:{minute} {am_pm}","tomorrow at {hour}:{minute} {am_pm}"],"global_to_top":"Go up","global_user_is_online":"online","global_user_is_online_mobile":"online from mobile","global_word_hours_ago":["","one hour ago","two hours ago","three hours ago","four hours ago","five hours ago"],"global_word_mins_ago":["","one minute ago","two minutes ago","three minutes ago","4 minutes ago","5 minutes ago"],"months_of":{"1":"January","2":"February","3":"March","4":"April","5":"May","6":"June","7":"July","8":"August","9":"September","10":"October","11":"November","12":"December"},"months_sm_of":{"1":"Jan","2":"Feb","3":"Mar","4":"Apr","5":"May","6":"Jun","7":"Jul","8":"Aug","9":"Sep","10":"Oct","11":"Nov","12":"Dec"}});
addTemplates({"_":"_","stickers_sticker_url":"https:\/\/vk.com\/sticker\/1-%id%-%size%"});
window.cur = window.cur || {};
cur['emojiHintsSendLogHash']="b88e373dd4e191f0ca";
cur.options = {"bmonths":[[0,"Month"],[1,"January"],[2,"February"],[3,"March"],[4,"April"],[5,"May"],[6,"June"],[7,"July"],[8,"August"],[9,"September"],[10,"October"],[11,"November"],[12,"December"]],"byears":[[0,"Year"],[2006,"2006"],[2005,"2005"],[2004,"2004"],[2003,"2003"],[2002,"2002"],[2001,"2001"],[2000,"2000"],[1999,"1999"],[1998,"1998"],[1997,"1997"],[1996,"1996"],[1995,"1995"],[1994,"1994"],[1993,"1993"],[1992,"1992"],[1991,"1991"],[1990,"1990"],[1989,"1989"],[1988,"1988"],[1987,"1987"],[1986,"1986"],[1985,"1985"],[1984,"1984"],[1983,"1983"],[1982,"1982"],[1981,"1981"],[1980,"1980"],[1979,"1979"],[1978,"1978"],[1977,"1977"],[1976,"1976"],[1975,"1975"],[1974,"1974"],[1973,"1973"],[1972,"1972"],[1971,"1971"],[1970,"1970"],[1969,"1969"],[1968,"1968"],[1967,"1967"],[1966,"1966"],[1965,"1965"],[1964,"1964"],[1963,"1963"],[1962,"1962"],[1961,"1961"],[1960,"1960"],[1959,"1959"],[1958,"1958"],[1957,"1957"],[1956,"1956"],[1955,"1955"],[1954,"1954"],[1953,"1953"],[1952,"1952"],[1951,"1951"],[1950,"1950"],[1949,"1949"],[1948,"1948"],[1947,"1947"],[1946,"1946"],[1945,"1945"],[1944,"1944"],[1943,"1943"],[1942,"1942"],[1941,"1941"],[1940,"1940"],[1939,"1939"],[1938,"1938"],[1937,"1937"],[1936,"1936"],[1935,"1935"],[1934,"1934"],[1933,"1933"],[1932,"1932"],[1931,"1931"],[1930,"1930"],[1929,"1929"],[1928,"1928"],[1927,"1927"],[1926,"1926"],[1925,"1925"],[1924,"1924"],[1923,"1923"],[1922,"1922"],[1921,"1921"],[1920,"1920"],[1919,"1919"],[1918,"1918"],[1917,"1917"],[1916,"1916"],[1915,"1915"],[1914,"1914"],[1913,"1913"],[1912,"1912"],[1911,"1911"],[1910,"1910"],[1909,"1909"],[1908,"1908"],[1907,"1907"],[1906,"1906"],[1905,"1905"],[1904,"1904"],[1903,"1903"],[1902,"1902"]]};
Index.initNew();cur.fbApp = '128749580520227';
cur.fbState = 'e84b3827c5c9ff22c7';
cur.fbLocale = 'en_US';
Index.fbCheck(cur.fbApp, '');
;(function (d, w) {
if (w.__dev) {
  return
}
var ts = d.createElement("script"); ts.type = "text/javascript"; ts.async = true;
ts.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//top-fwz1.mail.ru/js/code.js";
var f = function () {var s = d.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ts, s);};
if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); }
})(document, window);
      window.curReady && window.curReady();
    }
  </script>
</body>

</html>