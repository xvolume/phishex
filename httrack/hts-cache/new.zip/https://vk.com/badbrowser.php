<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
  <head>
    <meta http-equiv="content-type" content="text/html; charset=windows-1251" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="google-site-verification" content="CNjLCRpSR2sryzCC4NQKKCL5WnvmBTaag2J_UlTyYeQ" />

    <title>Your browser is out of date</title>

    <link rel="stylesheet" type="text/css" href="/css/al/common.css?66577870638" /><link rel="stylesheet" type="text/css" href="/css/al/base.css?1" /><link rel="stylesheet" type="text/css" href="/css/al/fonts_utf.css?1" /><link rel="stylesheet" type="text/css" href="/css/al/fonts_cnt.css?7802460376" />
    <link rel="stylesheet" type="text/css" href="/css/al/away.css?20958506997" />
  </head>

  <body>
    <div class="away_wrap page_block">
      <div class="away_head"><a href="/" class="away_logo"></a></div>
      <div class="away_content bad_browser">
        <h2>Your browser is out of date</h2>
        
        <div>
          This may cause VK to work slowly or experience errors. For speed and stability, we recommend you install the latest version of one of the following browsers:
          <div class="good_browsers"><a href="https://vk.com/away.php?to=https%3A%2F%2Fwww.google.com%2Fchrome&amp;badbrowser=chrome" target="_blank" class="good_browser"><div class="browser_icon chrome"></div>Chrome</a><a href="https://vk.com/away.php?to=https%3A%2F%2Fwww.mozilla.org&amp;badbrowser=firefox" target="_blank" class="good_browser"><div class="browser_icon firefox"></div>Firefox</a><a href="https://vk.com/away.php?to=https%3A%2F%2Fwww.opera.com&amp;badbrowser=opera" target="_blank" class="good_browser"><div class="browser_icon opera"></div>Opera</a></div>
        </div>
        Alternatively, you can use <a href="https://m.vk.com">the mobile version of the website</a>.
      </div>
    </div>
  </body>
</html>